//import Foundation
//
//public class APIService2 {
//    
//    public static let shared = APIService2()
//    
//    public func getData() {
//        guard let url = URL(string: "https://gateway.apiportal.ns.nl/reisinformatie-api/api/v3/disruptions?isActive=true") else { return }
//        var request = URLRequest(url: url)
//        request.httpMethod = "GET"
//        request.setValue("b7f5d30ce89b4183b1052163b990beca", forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
//        
//        URLSession.shared.dataTask(with: request) { (data, response, error) in
//            guard let data = data else { return }
//            
//            let finalData = try! JSONDecoder().decode([NSDisruptions].self, from: data)
//            for i in 0..<finalData.count {
//                print("\(i)")
//                print(finalData[i].title)
//                print("     \(finalData[i].type)")
//                print("     \(finalData[i].expectedDuration?.description ?? "Geen beschrijving")")
//                print("     \(finalData[i].summaryAdditionalTravelTime?.minimumDurationInMinutes ?? 0)")
//                print("     \(finalData[i].publicationSections?[0].section?.stations?[0].name ?? "Geen station")")
//                print("     \(finalData[i].publicationSections?[0].section?.stations?[0].coordinate?.lat ?? 50.4)")
//                print("     \(finalData[i].timespans?[0].cause.label ?? "Oorzaak onbekend")")
//            }
//            
//        }.resume()
//    }
//}




